package jUnitTestPackage;

public class jUnitFunctions {
	public int addNumbers(int num1, int num2) {
		return num1+num2;
	}
	public String addStrings(String s1, String s2) {
		return s1+s2 ;
	}
}
